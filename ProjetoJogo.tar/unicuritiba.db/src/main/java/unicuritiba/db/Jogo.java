package unicuritiba.db;

public class Jogo {
	
	private String nome;
	private String tema;
	private int pontMax;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTema() {
		return tema;
	}
	public void setTema(String tema) {
		this.tema = tema;
	}
	public int getPontMax() {
		return pontMax;
	}
	public void setPontMax(int pontMax) {
		this.pontMax = pontMax;
	}
	
	

}
