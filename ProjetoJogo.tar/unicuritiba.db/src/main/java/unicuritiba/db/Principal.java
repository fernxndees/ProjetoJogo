package unicuritiba.db;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Principal {
	public static void main(String[] args, JogadorDao cadastro) {
		JogadorDao cadastro1 = new JogadorDao();
		String menu = "1 - Cadastrar o jogador" + "\n2 - Atualizar dados de um jogador" + "\n3 - Deletar um jogador"
				+ "\n4 - Mostrar lista de jogadores" + "\n5 - Mostrar determinado jogador";
		int op;
		do {
			op = Integer.parseInt(JOptionPane.showInputDialog(menu));
			switch (op) {
			case 1: {
				String nome = JOptionPane.showInputDialog("Nome?");
				String apelido = JOptionPane.showInputDialog("Apelido?");
				Jogador p = new Jogador(nome, apelido);
				cadastro1.inserir(p);
				break;
			}
			case 2: {
				String nome = JOptionPane.showInputDialog("Qual seu novo nome?");
				String apelido = JOptionPane.showInputDialog("Qual seu novo apelido?");
				int id = Integer.parseInt(JOptionPane.showInputDialog("ID?"));
				Jogador p = new Jogador(nome, apelido);
				p.setNome(nome);
				p.setApelido(apelido);
				p.setId(id);
				cadastro1.atualizar(p);
				break;
				}
			case 3:{
				int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
				cadastro1.apagar(id);
				break;
			}
				case 4:{
				List<Jogador> pessoas = new ArrayList<>();
				cadastro.listar();
				for (int index=0;index<pessoas.size();index++) {
				System.out.println(pessoas.get(index).toString());
				}
				break;
				}
				case 5:{
					int id = Integer.parseInt(JOptionPane.showInputDialog("ID?"));
					Jogador p = new Jogador();
					p = cadastro.mostraPorId(id);
					if (!p.getNome().equals("")) {
						System.out.println(p);
					}
					break;
					}
				case 0:
					break;
				default:
					JOptionPane.showMessageDialog(null, "Opção inválida");
				}

			}while (op != 0);
		}

	}